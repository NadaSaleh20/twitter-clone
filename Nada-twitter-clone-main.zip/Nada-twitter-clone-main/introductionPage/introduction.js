const nextButton =document.getElementById("next");
nextButton.onclick = function () {
    location.href = "../loginPage/login.html";
}